import { useState, useEffect } from 'react';

export const useTheme = (initialTheme = 'light') => {
  const [theme, setTheme] = useState(() => {
    // Optional: Check local storage for saved theme preference
    // const savedTheme = localStorage.getItem('theme');
    // return savedTheme || initialTheme;
    return initialTheme === 'dark'; // Assuming initialTheme is 'light' or 'dark'
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme) {
      root.classList.add('dark');
      // Optional: Save theme preference to local storage
      // localStorage.setItem('theme', 'dark');
    } else {
      root.classList.remove('dark');
      // Optional: Save theme preference to local storage
      // localStorage.setItem('theme', 'light');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prevTheme => !prevTheme);
  };

  return { isDark: theme, toggleTheme };
};

