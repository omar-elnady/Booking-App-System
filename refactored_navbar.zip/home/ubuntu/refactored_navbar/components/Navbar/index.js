import React from 'react';
import { useTranslation } from 'react-i18next';
import { getBasicLinks } from '../../constants'; // Corrected path
import { useTheme } from '../../hooks/useTheme'; // Corrected path
import { useLanguage } from '../../hooks/useLanguage'; // Corrected path
import Logo from './Logo';
import NavLinks from './NavLinks';
import LanguageSwitcher from './LanguageSwitcher';
import ThemeSwitcher from './ThemeSwitcher';
import AuthSection from './AuthSection';
import MobileMenu from './MobileMenu';

const Navbar = () => {
  // Initialize hooks
  useTheme(); // Manages theme state and applies dark class
  const { t } = useLanguage(); // Provides translation function and manages language state

  // Get data from constants (passing t for translation)
  const basicLinks = getBasicLinks(t);
  const logoText = t('navbar.logoName');

  return (
    <nav className="bg-white blurred dark:bg-darkNavbar shadow-lg border-b transition-colors duration-500 border-gray-600 dark:border-gray-700 z-50">
      <div className="container mx-auto">
        <div className="flex justify-between items-center h-16">
          {/* Logo Section */}
          <Logo logoText={logoText} />

          {/* Desktop Navigation Links */}
          <NavLinks links={basicLinks} />

          {/* Right Section: Language, Theme, Auth, Mobile Menu */}
          <div className="flex items-center space-x-4">
            {/* Language Switcher (Desktop) */}
            <LanguageSwitcher />

            {/* Theme Switcher (Desktop + Mobile Icon) */}
            <ThemeSwitcher />

            {/* Authentication Section (Desktop Buttons + Mobile Icon) */}
            {/* Note: AuthSection handles logic for authenticated/unauthenticated states */}
            <AuthSection />

            {/* Mobile Menu Trigger */}
            {/* Pass basic links; you might want to combine auth links here too */}
            <MobileMenu links={basicLinks} />
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

