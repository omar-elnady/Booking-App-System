import React from 'react';
import CustomDropdown from '../../Combox'; // Assuming path relative to components/Navbar
import { useLanguage } from '../../hooks/useLanguage'; // Corrected path

const LanguageSwitcher = () => {
  const { i18n, selectedLang, languagesOptions, handleSetLang } = useLanguage();

  return (
    <div
      className={`items-center space-x-2 ${
        i18n.language === 'en'
          ? 'border-r pr-4 mr-4' // Conditional styling based on language
          : 'border-l pl-4 ml-4'
      } border-gray-300 dark:border-gray-600 hidden md:flex`} // Added dark mode border, keep hidden on mobile
    >
      <CustomDropdown // Using the original name from import
        value={selectedLang}
        options={languagesOptions}
        setValue={handleSetLang} // Use the handler from the hook
      />
    </div>
  );
};

export default LanguageSwitcher;

